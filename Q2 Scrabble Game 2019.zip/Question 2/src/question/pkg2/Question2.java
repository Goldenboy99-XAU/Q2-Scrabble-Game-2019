
package question.pkg2;

import java.util.Scanner;


public class Question2 
{
    //declaring variables to hold player names
    private static String player1;
    private static String player2;
    private static String currentPlayer;
    private static int playerNumber = 1;
    //declaring variable to hold the value of played word
    private static String playedWord = "";
    //declaring a variable to hold the alphabet list
    private static String alphabetList = "a b c d e f g h i j k l m n o p q r s t u v w x y z";
    //declaring a variable to store used letters
    private static String usedLetters = "";
    //declaring a variable to update alphabet
    private static boolean updateAlphabets = true;
    //declarimg variables for players scores
    private static int p1Score = 0;
    private static int p2Score = 0;
    
    public static void main(String[] args) 
    {
        System.out.println("Welcom to the WARD WAR GAME.");
        System.out.println("\nPress (y) To start the game.");
        System.out.println("\nPress any other key to exit the game");
        System.out.print("Enter your selection: ");
        if(new Scanner(System.in).next().equalsIgnoreCase("y"))
        {
            System.out.print("\n*****************************************");
            //prompt for pleyer 1 name
            System.out.print("\nEnter player 1 name: ");
            player1 = new Scanner(System.in).next();
            //prompt for pleyer 2 name
            System.out.print("\nEnter player 2 name: ");
            player2 = new Scanner(System.in).next();
            //calling a method to start the game
            startGame();
        }
        else
        {
            //exiting the game
            System.exit(0);
        }
    }
//this method starts the game
    private static void startGame() 
    {
        System.out.println("LETS PLAY WORD WARS!!!");
        //while loop to loop the game
        while(!playedWord.equals("???"))
        {
            
            //determine the current player
            currentPlayer();
            System.out.print("\nAlphabet letters left: "+updateAlphabets());
            System.out.print("\n"+currentPlayer+" enter your word: ");
            playedWord = new Scanner(System.in).next();
           
            //calling a method to validate played word
            validatingPlayedWord();
           
        }
        //calling a method to display scores
        playersScore();
    }
//this method updates the alphabet list
    private static String updateAlphabets() 
    {
      if(updateAlphabets == true)
      {
        //for loop to loop through the alphabet list
        for(int i = 0;i < alphabetList.toCharArray().length;i++)
        {
            //get used letters
            if(playedWord.contains( (alphabetList.toCharArray()[i]+"") ))
            {
                usedLetters = (alphabetList.toCharArray()[i]+"");
                alphabetList = alphabetList.replace((alphabetList.toCharArray()[i]+""), " ");
            }
        }
      }
      else
      {
          System.out.print("\nYOU ENTERED A WORD THAT CONTAINS A LETTER THAT IS USED OR IS NOT VALID, PLEASE ENTER ANOTHER WORD!");
          updateAlphabets = true;
      }
        return alphabetList;
        
    }
//this method determines the current player
    private static void currentPlayer() 
    {
        if(playerNumber == 1)
        {
            currentPlayer = player1;
            playerNumber += 1;
        }
        else
        {
            currentPlayer = player2;
            playerNumber -= 1;
        }
    }
//this method removes vowels from played word
    private static void trimVowels() 
    {
        String vowels = "a e i o u";
        //looping through played word variable
        for(int i = 0;i < playedWord.toCharArray().length;i++)
        {
            if(vowels.contains( (playedWord.toCharArray()[i]+"") ))
            {
                playedWord = playedWord.replace((playedWord.toCharArray()[i]+""), "");
            }
        }
    }
//this method validates the played word
    private static void validatingPlayedWord() 
    {
        System.out.print("\nEnter (y) if both players agree on the word or enter any key to disagree: ");
        if(new Scanner(System.in).next().equalsIgnoreCase("y"))
        {
            //calling a method to search for a used letter
            usedLetterSearch();
            //calling a method to trim vowels
            trimVowels();
            //calling a method to determine players score
            determiningScore();
        }
        else
        {
            playedWord = "";
        }
    }

    private static void usedLetterSearch() 
    {
        //looping through used letters
        for(int i = 0;i < usedLetters.toCharArray().length;i++)
        {
            if(playedWord.contains( (usedLetters.toCharArray()[i]+"") ))
            {
                updateAlphabets = false;
            }
        }
    }
//this method displays players score
    private static void playersScore() 
    {
        System.out.print("\n"+player1+" Score: "+p1Score+
                         "\n"+player2+" Score: "+p2Score);
        System.out.print("\nCONGRATULATIONS TO THE WINNER. YOUR NAME HAS BEEN SAVE ON HE HALL OF FAME!!!");
        System.out.print("\nnTHE GAME IS OVER. THANK YOU FOR PLAYING WORD WARS!!!");
        
    }
//this method determines the score
    private static void determiningScore() 
    {
        //checking the name of the current player
        if(currentPlayer.equals(player1)&& !playedWord.equals("???"))
        {
            p1Score += 1;
        }
        
        if(currentPlayer.equals(player2)&& !playedWord.equals("???"))
        {
            p2Score += 1;
        }
    }
    
}
